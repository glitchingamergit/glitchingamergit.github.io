let blockedSites = [];

fetch('https://ikau-os.github.io/asset/chrome-extension-resrc/blockedSites.json')
  .then(response => response.json())
  .then(data => {
    blockedSites = data;
    console.log("🛡️ Forcefield loaded and ready to block:", blockedSites);
  })
  .catch(error => {
    console.error("Oops! The Forcefield couldn't load the list:", error);
  });

chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId === 0 && blockedSites.length > 0) {
      const currentUrl = new URL(details.url);
      const isBlocked = blockedSites.some(site => currentUrl.hostname.includes(site));

      if (isBlocked) {
          console.log("🛑 Access Denied to:", currentUrl.hostname);
          const redirectUrl = chrome.runtime.getURL("blocked/blocked.html?url=" + encodeURIComponent(currentUrl.href));
          
          chrome.tabs.update(details.tabId, { url: redirectUrl });
      }
  }
});

// /* "https://ikau-os.github.io/asset/chrome-extension-resrc/blockedSites.jsonc" */
// fetch("sites.json")
// .then(response => {
//     if (!response.ok) {
//         throw new Error("External file not found or server error");
//     }
//     return response.json();
// })

// .catch(error => {
//     console.warn("Primary fetch failed:", error.message);

//     // return fetch(chrome.runtime.getURL("sites.json"))
//     // .then(fallbackResponse => {
//     //     if (!fallbackResponse.ok) {
//     //         throw new Error("Local fallback file also failed to load");
//     //     }
//     //     return fallbackResponse.json();
//     // });
// })
// // .then(data => {
// //     blockedSites = data;
// //     console.log("Forcefield loaded with these sites:", blockedSites);
// // })

// // .catch(error => {
// //     console.error("Critical Error loading sites from both sources:", error);
// // });

// chrome.webNavigation.onBeforeNavigate.addListener((details) => {
//     if (details.frameId === 0 && blockedSites.length > 0) {
//         const currentUrl = new URL(details.url);
//         const isBlocked = blockedSites.some(site => currentUrl.hostname.includes(site));

//         if (isBlocked) {
//             const redirectUrl = chrome.runtime.getURL("blocked.html");
//             chrome.tabs.update(details.tabId, { url: redirectUrl });
//         }
//     }
// });
