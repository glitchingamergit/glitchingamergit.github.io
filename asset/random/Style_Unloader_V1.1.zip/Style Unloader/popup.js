document.addEventListener('DOMContentLoaded', () => {
  const statusText = document.getElementById('statusText');
  const toggleBtn = document.getElementById('toggleBtn');
  const hostnameDisplay = document.getElementById('hostnameDisplay');

  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    if (!tabs[0].url || tabs[0].url.startsWith('chrome://')) {
        statusText.textContent = "Cannot run on System Pages";
        hostnameDisplay.textContent = "N/A";
        toggleBtn.disabled = true;
        return;
    }

    const url = new URL(tabs[0].url);
    const currentHost = url.hostname;
    hostnameDisplay.textContent = currentHost;

    chrome.storage.sync.get(['activeSites'], function(result) {
      let activeSites = result.activeSites || [];
      let isActive = activeSites.includes(currentHost);

      updateUI(isActive);

      toggleBtn.addEventListener('click', () => {
        if (isActive) {
          activeSites = activeSites.filter(host => host !== currentHost);
        } else {
          activeSites.push(currentHost);
        }

        chrome.storage.sync.set({activeSites: activeSites}, () => {
          isActive = !isActive;
          updateUI(isActive);
          chrome.tabs.reload(tabs[0].id);
        });
      });
    });

    function updateUI(active) {
        if (active) {
            statusText.textContent = "Text Mode: ON";
            statusText.style.color = "green";
            toggleBtn.textContent = "Restore Full Site";
        } else {
            statusText.textContent = "Text Mode: OFF";
            statusText.style.color = "gray";
            toggleBtn.textContent = "Enable Text Mode";
        }
    }
  });
});
