function stripPage() {
  const styleLinks = document.querySelectorAll('link[rel="stylesheet"]');
  styleLinks.forEach(link => link.remove());

  const visuals = document.querySelectorAll('img, picture, svg');
  visuals.forEach(visual => visual.remove());
}

const currentHost = window.location.hostname;

chrome.storage.sync.get(['activeSites'], function(result) {
  let activeSites = result.activeSites || [];
  

  if (activeSites.includes(currentHost)) {
     stripPage();

     const observer = new MutationObserver((mutations) => {
       let shouldStrip = false;
       for (let mutation of mutations) {
         if (mutation.addedNodes.length) {
           shouldStrip = true;
           break;
         }
       }
       if (shouldStrip) stripPage();
     });

     observer.observe(document.body, { childList: true, subtree: true });
  }
});
